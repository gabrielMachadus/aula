package testesistema;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import junit.framework.Assert;
import mock.CorreioService;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import static org.mockito.Mockito.when;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author marcelo.soares
 */
public class SeleniumTest {

	public static WebDriver driver = null;
	public final static String CAMINHO_ARQUIVO_TESTE = "C:\\Users\\fatec.senai\\Documents\\NetBeansProjects\\aula-qts\\src\\main\\java\\sistema\\index.html";
	public final static String DRIVER_PATH = "C:\\chromedriver_win32\\chromedriver.exe";
	private static String namePaginaPrincipal; 

	public SeleniumTest() {
	}

	@BeforeAll
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver", DRIVER_PATH); 
		driver = new ChromeDriver();
		driver.get(CAMINHO_ARQUIVO_TESTE);
		namePaginaPrincipal = driver.getWindowHandle();
	}

	@Test
	public void testTituloPaginaLogin() {
		driver.get(CAMINHO_ARQUIVO_TESTE);
		String tituloExperado = "Trabalho 2-1";
		Assert.assertEquals(tituloExperado, driver.getTitle());
	}

	        
        @Test
	public void testCamposSucesso() {
		driver.get(CAMINHO_ARQUIVO_TESTE);
		WebElement campoNome = driver.findElement(By.id("nome"));
                WebElement endereco = driver.findElement(By.id("endereco"));
                WebElement sexo = driver.findElement(By.id("sexo"));
                WebElement idade = driver.findElement(By.id("idade"));
                
                
                campoNome.sendKeys("Gabriel");
                endereco.sendKeys("abc");
                sexo.sendKeys("Masculino");
                idade.sendKeys("10");
                
                WebElement submit = driver.findElement(By.id("botao_salvar"));
                submit.click();               
                  Alert alert = driver.switchTo().alert();
        

		Assert.assertEquals("Cadastro realizado com sucesso",   alert.getText());
	}
        
        @Test
        public void testCep(){
            driver.get(CAMINHO_ARQUIVO_TESTE);
             WebElement cep = driver.findElement(By.id("cep"));
          CorreioService correio =  Mockito.mock(CorreioService.class);
		when(correio.buscaEndereco(cep.getText()).thenReturn("Porto Alegre"));
//Caso o usuário inserir o valor “9000000”, retornar “Porto Alegre”
//Caso o usuário inserir o valor “8000000”, retornará “Av. Assis Brasil”

        }
        
//        @Test
//	public void testCampoNomeBranco() {
//		driver.get(CAMINHO_ARQUIVO_TESTE);
//		WebElement campoNome = driver.findElement(By.id("nome"));
//                campoNome.sendKeys("");
//		WebElement submit = driver.findElement(By.id("salvar"));
//                WebElement alerta = driver.findElement( By.id("erroMensagem"));
//		submit.click();
//		Assert.assertEquals("Preencha o campo nome",alerta.getText());
//	}
        
//        @Test
//        public void testeCampoEndereco(){
//            WebElement campoEndereco = driver.findElement(By.id("endereco"));
//            campoEndereco.sendKeys("teste");
//            WebElement submit = driver.findElement(By.id("salvar"));
//            submit.click();
//        }
//        
//        @Test
//        public void testeCampoEnderecoBranco(){
//            WebElement campoEndereco = driver.findElement(By.id("endereco"));
//            campoEndereco.sendKeys("teste");
//            WebElement submit = driver.findElement(By.id("salvar"));
//            submit.click();
//        }
//        
        

	

	@AfterAll
	public static void tearDown() {
		driver.quit();
	}

}
